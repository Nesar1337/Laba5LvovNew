let a = (2 + 3) * (2 + 3);
alert(a);

let i = (2 + 3) * 2 + 3;
alert(i);

let u = 2 * (2 + 4 * (3 + 1));
alert(u);

let p = 2 * 8 / 4;
alert(p);

let o = (2 * 8) / 4;
alert(o);

let y = 2 * (8 / 4);
alert(y);