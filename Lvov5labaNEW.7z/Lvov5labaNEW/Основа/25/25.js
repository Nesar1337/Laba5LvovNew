let a = 13;
let b = 5;
alert(a % b);