let str = 'lvov ilya';
alert(str);