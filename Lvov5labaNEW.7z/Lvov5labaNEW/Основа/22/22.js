let a = (2 + 3) * (2 + 3);
alert(a);

let d = (2 + 3) * 2 + 3;
alert(d);

let s = 2 * (2 + 4 * (3 + 1));
alert(s);

let t = 2 * 8 / 4;
alert(t);

let h = (2 * 8) / 4;
alert(h);

let k = 2 * (8 / 4);
alert(k);