alert('eeee'); // eeeeee
/*
		eeeeeeeee
*/
alert('EEEEEE');