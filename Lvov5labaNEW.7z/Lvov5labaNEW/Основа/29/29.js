let str = '!!!';
let str1 = 'java';
let str2 = 'script';
alert(str);
alert(str1 + str2);