let a = 8 / 2 * 2;
alert(a);

let b = 8 * 4 / 2 / 2;
alert(b);