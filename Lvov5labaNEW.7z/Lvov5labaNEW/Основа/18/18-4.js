let a = 10;
let b = 5;
let d = 7;
let c = a - b;
alert(c + d);
