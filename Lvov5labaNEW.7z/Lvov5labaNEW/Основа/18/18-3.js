let a = 1;
let b = 2;
let c = 3;
alert(a + b + c);
