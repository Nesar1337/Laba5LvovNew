let a = 3 * 2 ** 3;
alert(a);

let p = (3 * 2) ** 3;
alert(p);

let o = 3 * 2 ** (3 + 1);
alert(o);

let i = 2 ** 3 * 3;
alert(i);

let u = 3 * 2 ** 3 * 3;
alert(u);