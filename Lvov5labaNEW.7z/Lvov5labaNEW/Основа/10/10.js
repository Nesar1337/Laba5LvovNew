"use strict";
alert('eeee');