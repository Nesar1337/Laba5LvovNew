"eeee";
let num = 123;
alert(num);