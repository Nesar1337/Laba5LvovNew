let str = 'abcde';
alert(str.length); // выведет 5